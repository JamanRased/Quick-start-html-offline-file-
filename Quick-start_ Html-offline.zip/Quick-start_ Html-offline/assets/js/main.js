$(document).ready(function(){
	$("#slider").owlCarousel({
		items: 1,
		autoplay: true,
		autoplayTimeout: 1000,
		dots: false,
		nav:true,
	});
});

	
